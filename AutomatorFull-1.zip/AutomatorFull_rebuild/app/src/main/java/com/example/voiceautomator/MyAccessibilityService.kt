
package com.example.voiceautomator

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MyAccessibilityService : AccessibilityService() {

    companion object { var instance: MyAccessibilityService? = null; private set }

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onInterrupt() {}
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    fun globalBack() { performGlobalAction(GLOBAL_ACTION_BACK) }
    fun globalHome() { performGlobalAction(GLOBAL_ACTION_HOME) }
    fun globalRecents() { performGlobalAction(GLOBAL_ACTION_RECENTS) }

    fun scroll(down: Boolean) {
        val path = Path().apply { moveTo(500f, if(down) 1500f else 500f); lineTo(500f, if(down) 500f else 1500f) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 300)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    fun tapByText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = findNodesByText(root, text)
        val target = nodes.firstOrNull { it.isClickable } ?: nodes.firstOrNull()
        return if (target != null) { performClick(target); true } else false
    }

    fun tapXY(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y); lineTo(x + 1f, y + 1f) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 50)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    fun typeText(text: String) {
        val root = rootInActiveWindow ?: return
        val editable = findFirstEditable(root) ?: return
        val args = android.os.Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        editable.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun tryTapSend() {
        val root = rootInActiveWindow ?: return
        val candidates = findNodesByText(root, "Send")
        candidates.firstOrNull()?.let { performClick(it) }
    }

    private fun performClick(node: AccessibilityNodeInfo) {
        var n: AccessibilityNodeInfo? = node
        while (n != null) {
            if (n.isClickable) { n.performAction(AccessibilityNodeInfo.ACTION_CLICK); break }
            n = n.parent
        }
    }

    private fun findNodesByText(node: AccessibilityNodeInfo, text: String): List<AccessibilityNodeInfo> {
        val list = mutableListOf<AccessibilityNodeInfo>()
        fun dfs(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = n.text?.toString() ?: ""
            val d = n.contentDescription?.toString() ?: ""
            if (t.contains(text, true) || d.contains(text, true)) list.add(n)
            for (i in 0 until n.childCount) dfs(n.getChild(i))
        }
        dfs(node); return list
    }

    private fun findFirstEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable || node.className?.toString()?.contains("EditText") == true) return node
        for (i in 0 until node.childCount) {
            val c = node.getChild(i); val r = c?.let { findFirstEditable(it) }
            if (r != null) return r
        }
        return null
    }
}
