
package com.example.voiceautomator

import android.os.Bundle
import android.speech.RecognitionListener

class SimpleRecognitionListener(
    private val onFinal: (String) -> Unit,
    private val onErrorText: (String) -> Unit,
    private val onPartial: (String) -> Unit
): RecognitionListener {
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onError(error: Int) { onErrorText("speech error $error") }
    override fun onResults(results: Bundle?) {
        val text = results?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
        onFinal(text)
    }
    override fun onPartialResults(partialResults: Bundle?) {
        val text = partialResults?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
        if(text.isNotEmpty()) onPartial(text)
    }
    override fun onEvent(eventType: Int, params: Bundle?) {}
}
