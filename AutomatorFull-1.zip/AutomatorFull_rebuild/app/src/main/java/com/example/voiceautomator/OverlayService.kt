
package com.example.voiceautomator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.app.NotificationCompat

class OverlayService : Service() {
    private var wm: WindowManager? = null
    private var box: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundIfNeeded()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        box = LayoutInflater.from(this).inflate(R.layout.overlay_toolbox, null)
        box?.findViewById<ImageView>(R.id.btnShot)?.setOnClickListener {
            sendBroadcast(Intent("com.example.voiceautomator.ACTION_SCREENSHOT").setPackage(packageName))
        }
        box?.findViewById<ImageView>(R.id.btnCmds)?.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        box?.findViewById<ImageView>(R.id.btnMacros)?.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        box?.findViewById<ImageView>(R.id.btnPause)?.setOnClickListener { stopSelf() }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        wm?.addView(box, params)
    }

    private fun startForegroundIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val chanId = "automator_overlay"
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(chanId, "Overlay", NotificationManager.IMPORTANCE_MIN))
            val n: Notification = NotificationCompat.Builder(this, chanId)
                .setContentTitle("Automator")
                .setContentText("Floating toolbox")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build()
            startForeground(3, n)
        }
    }

    override fun onDestroy() { super.onDestroy(); box?.let { wm?.removeView(it) } }
}
