
package com.example.voiceautomator

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.preference.PreferenceManager
import java.util.Locale

class CommandEngine(private val ctx: Context) {

    private val svc: MyAccessibilityService? get() = MyAccessibilityService.instance
    private val prefs by lazy { PreferenceManager.getDefaultSharedPreferences(ctx) }

    fun handle(raw: String): String {
        val text = raw.lowercase(Locale.getDefault()).trim()

        if(text.startsWith("record macro")) { MacroManager.startRecording(); return "Recording macro… 'stop macro [name]' to save." }
        if(text.startsWith("stop macro")) {
            val name = text.removePrefix("stop macro").trim().ifEmpty { "macro" + System.currentTimeMillis() }
            MacroManager.stopAndSave(ctx, name); return "Saved macro '$name'"
        }
        if(text.startsWith("run ") || text.startsWith("play ")) {
            val name = text.substring(text.indexOf(' ')+1).trim()
            val steps = MacroManager.load(ctx, name)
            return if(steps != null){
                for(step in steps){ handle(step); Thread.sleep((prefs.getString("default_wait_ms","500")?: "500").toLong()) }
                "Macro '$name' executed"
            } else "No macro named '$name'"
        }

        if(text == "back") { svc?.globalBack(); return "Action: back" }
        if(text == "home") { svc?.globalHome(); return "Action: home" }
        if(text.contains("recents")) { svc?.globalRecents(); return "Action: recents" }
        if(text.startsWith("scroll")) { val down = !text.contains("up"); svc?.scroll(down); return "Action: scroll " + (if(down)"down" else "up") }

        if(text.startsWith("tap ")) {
            val parts = text.split(" ")
            if(parts.size == 3 && parts[1].toFloatOrNull()!=null && parts[2].toFloatOrNull()!=null){
                val x = parts[1].toFloat(); val y = parts[2].toFloat(); svc?.tapXY(x,y); return "Tapped at ($x,$y)"
            } else {
                val needle = text.removePrefix("tap ").trim()
                val ok = svc?.tapByText(needle) == true; MacroManager.maybeRecord(raw)
                return if(ok) "Tapped \"$needle\"" else "Could not find \"$needle\""
            }
        }

        if(text.startsWith("type ")) { val body = text.removePrefix("type ").trim(); svc?.typeText(body); MacroManager.maybeRecord(raw); return "Typed: $body" }
        if(text.startsWith("open ")) {
            val appName = text.removePrefix("open ").trim(); val ok = AppOpener.openAppByName(ctx, appName); MacroManager.maybeRecord(raw)
            return if(ok) "Opening $appName" else "App '$appName' not found"
        }
        if(text.startsWith("call ")) {
            val num = text.removePrefix("call ").filter { it.isDigit() || it == '+' }; val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")).apply{ flags = Intent.FLAG_ACTIVITY_NEW_TASK }
            ctx.startActivity(i); MacroManager.maybeRecord(raw); return "Dialer opened with $num"
        }
        if(text.startsWith("text ")) {
            val rest = text.removePrefix("text ").trim(); val firstSpace = rest.indexOf(' ')
            if(firstSpace > 0) { val num = rest.substring(0, firstSpace); val body = rest.substring(firstSpace + 1)
                val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num")).apply { putExtra("sms_body", body); flags = Intent.FLAG_ACTIVITY_NEW_TASK }
                ctx.startActivity(i); MacroManager.maybeRecord(raw); return "Prepared SMS to $num"
            }
        }

        if(text.contains("wifi") && text.contains("settings")) { ctx.startActivity(Intent(Settings.Panel.ACTION_WIFI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); MacroManager.maybeRecord(raw); return "Opening Wi‑Fi panel" }
        if(text.contains("bluetooth") && text.contains("settings")) { ctx.startActivity(Intent(Settings.Panel.ACTION_BLUETOOTH).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); MacroManager.maybeRecord(raw); return "Opening Bluetooth panel" }
        if(text.contains("internet") && text.contains("settings")) { ctx.startActivity(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); MacroManager.maybeRecord(raw); return "Opening Internet panel" }
        if(text.contains("volume")) { ctx.startActivity(Intent(Settings.Panel.ACTION_VOLUME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); MacroManager.maybeRecord(raw); return "Opening volume panel" }

        if(text.startsWith("screenshot")) { return "Use overlay camera to screenshot & send to ChatGPT" }
        if(text.startsWith("open chatgpt") || text.contains("chatgpt")) { val ok = AppOpener.openAppByName(ctx, "ChatGPT"); return if(ok) "Opening ChatGPT" else "ChatGPT app not found" }

        return "Unknown: try 'open youtube', 'tap OK', 'tap 540 1280', 'type hello', 'back', 'scroll down', 'text 1234567890 hi'"
    }
}
