# Automator (Android)

**What it does**
- Offline-first hotword ("Automator") using device on‑device speech if available.
- Voice commands to open apps, tap by text/coordinates, back/home/recents, scroll, type text, call/text numbers, open system panels.
- Macro recorder: "record macro" → actions → "stop macro [name]" → "run [name]".
- Floating overlay toolbox (screenshot, commands, macros, pause).
- Screenshot + share to ChatGPT app; best-effort auto-tap Send.
- Share text from any app into Automator to execute as a command.

**Setup (in the app)**
1) Grant **Microphone**.
2) Enable **Accessibility → Automator**.
3) Allow **Display over other apps** → floating toolbox appears.
4) Start **Screen Capture** (approval once per session).
5) Tap **Start Hotword**. Say: “Automator, open YouTube”.

**Notes**
- Direct toggles (Wi‑Fi, Bluetooth, brightness) require system privileges; app opens panels instead.
- Hotword works offline if your device has the Google speech offline package installed; otherwise it may use network until you download it.

**Build with GitHub Actions**
- If you upload the **whole folder**, Actions will build immediately.
- If you upload just the ZIP, use the included workflow below that unzips first.