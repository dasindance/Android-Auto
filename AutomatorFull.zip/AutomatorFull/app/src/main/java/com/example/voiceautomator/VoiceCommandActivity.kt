package com.example.voiceautomator

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class VoiceCommandActivity : AppCompatActivity() {

    private lateinit var tv: TextView
    private var recognizer: SpeechRecognizer? = null
    private val engine by lazy { CommandEngine(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tv = TextView(this).apply { textSize = 18f; text = "Listening for command…" }
        setContentView(tv)

        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        recognizer?.setRecognitionListener(SimpleRecognitionListener(
            onFinal = { text ->
                tv.text = "Heard: " + text
                val res = engine.handle(text)
                tv.append("\\n" + res)
                finish()
            },
            onErrorText = { err -> tv.text = "Speech error: " + err; finish() },
            onPartial = { part -> tv.text = "Heard: " + part }
        ))
        recognizer?.startListening(intent)
    }

    override fun onDestroy() {
        recognizer?.destroy()
        super.onDestroy()
    }
}