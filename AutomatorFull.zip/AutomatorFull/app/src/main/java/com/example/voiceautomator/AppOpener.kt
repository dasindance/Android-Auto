package com.example.voiceautomator

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

object AppOpener {
    fun openAppByName(ctx: Context, name: String): Boolean {
        val pm = ctx.packageManager
        val pkgs = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val match = pkgs.firstOrNull { it.loadLabel(pm).toString().equals(name, ignoreCase = true) }
            ?: pkgs.firstOrNull { it.loadLabel(pm).toString().contains(name, ignoreCase = true) }
        return if (match != null) {
            val i = pm.getLaunchIntentForPackage(match.packageName)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i); true
            } else false
        } else false
    }
}