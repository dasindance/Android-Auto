package com.example.voiceautomator

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var logText: TextView
    private lateinit var micBtn: Button
    private lateinit var accBtn: Button
    private lateinit var overlayBtn: Button
    private lateinit var captureBtn: Button
    private lateinit var shareBtn: Button
    private lateinit var snapBtn: Button
    private lateinit var hotwordBtn: Button
    private lateinit var settingsBtn: Button

    private val engine by lazy { CommandEngine(this) }
    private val capture by lazy { ScreenCaptureManager(this) }

    private val audioPerm = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ){ granted -> addLog(if(granted) "Microphone granted" else "Microphone denied") }

    private val requestProjection = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ){ res ->
        if(res.resultCode == Activity.RESULT_OK && res.data != null){
            capture.onActivityResult(res.resultCode, res.data!!)
            addLog("Screen capture ready")
        } else addLog("Screen capture not granted")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        logText = findViewById(R.id.logText)
        micBtn = findViewById(R.id.micBtn)
        accBtn = findViewById(R.id.accBtn)
        overlayBtn = findViewById(R.id.overlayBtn)
        captureBtn = findViewById(R.id.captureBtn)
        shareBtn = findViewById(R.id.shareBtn)
        snapBtn = findViewById(R.id.snapBtn)
        hotwordBtn = findViewById(R.id.hotwordBtn)
        settingsBtn = findViewById(R.id.settingsBtn)

        if(intent?.action == Intent.ACTION_SEND && intent.type?.startsWith("text/") == true){
            val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: ""
            if(text.isNotBlank()){
                addLog("Shared text:\\n$text")
                val first = text.lines().firstOrNull()?.trim().orEmpty()
                if(first.isNotEmpty()) addLog(engine.handle(first))
            }
        }

        micBtn.setOnClickListener {
            if(ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED){
                audioPerm.launch(Manifest.permission.RECORD_AUDIO)
            } else addLog("Microphone already granted")
        }
        accBtn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            addLog("Enable 'Automator' in Accessibility")
        }
        overlayBtn.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.canDrawOverlays(this)) {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    startActivity(i)
                    addLog("Allow 'Display over other apps'")
                } else {
                    ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
                    addLog("Floating toolbox started")
                }
            }
        }
        captureBtn.setOnClickListener {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            requestProjection.launch(mpm.createScreenCaptureIntent())
        }
        snapBtn.setOnClickListener {
            capture.takeScreenshot { bmp ->
                if(bmp != null){
                    addLog("Screenshot captured")
                    shareBitmapToChatGPT(bmp)
                } else addLog("No capture permission yet")
            }
        }
        shareBtn.setOnClickListener {
            val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, logText.text.toString())
                type = "text/plain"
            }
            startActivity(Intent.createChooser(sendIntent, "Share via"))
        }
        hotwordBtn.setOnClickListener {
            ContextCompat.startForegroundService(this, Intent(this, HotwordService::class.java))
            addLog("Hotword service started ('Automator')")
        }
        settingsBtn.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        addLog("Tap each button top→down. Then 'Start Hotword'. Say: 'Automator, open YouTube' etc.")
    }

    private fun addLog(line: String){ logText.append(line + "\\n") }

    private fun shareBitmapToChatGPT(bmp: Bitmap){
        val uri = ImageStore.saveAndGetUri(this, bmp, "screenshot_${System.currentTimeMillis()}.png")
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            setPackage("com.openai.chatgpt")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(share)
            MyAccessibilityService.instance?.tryTapSend()
            addLog("Shared screenshot to ChatGPT")
        } catch (e: ActivityNotFoundException){
            startActivity(Intent.createChooser(share, "Share screenshot"))
            addLog("ChatGPT app not found; used chooser")
        }
    }
}