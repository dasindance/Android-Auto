package com.example.voiceautomator

import android.content.Context
import org.json.JSONArray

object MacroManager {
    private var recording = false
    private val temp = mutableListOf<String>()

    fun startRecording(){ recording = true; temp.clear() }
    fun maybeRecord(step: String){ if(recording) temp.add(step) }
    fun stopAndSave(ctx: Context, name: String){
        recording = false
        val arr = JSONArray()
        temp.forEach { arr.put(it) }
        val prefs = ctx.getSharedPreferences("macros", Context.MODE_PRIVATE)
        prefs.edit().putString(name, arr.toString()).apply()
    }
    fun load(ctx: Context, name: String): List<String>? {
        val prefs = ctx.getSharedPreferences("macros", Context.MODE_PRIVATE)
        val raw = prefs.getString(name, null) ?: return null
        val arr = JSONArray(raw)
        return List(arr.length()) { i -> arr.getString(i) }
    }
}