package com.example.voiceautomator

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.EditTextPreference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreferenceCompat

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportFragmentManager.beginTransaction()
            .replace(android.R.id.content, SettingsFrag())
            .commit()
    }
}

class SettingsFrag : PreferenceFragmentCompat() {
    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        preferenceManager.sharedPreferencesName = "automator_prefs"
        setPreferencesFromResource(R.xml.preferences, rootKey)

        findPreference<EditTextPreference>("hotword")?.setOnBindEditTextListener {
            it.hint = "automator"
        }
    }
}