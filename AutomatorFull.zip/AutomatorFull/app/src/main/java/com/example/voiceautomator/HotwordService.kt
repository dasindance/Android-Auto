package com.example.voiceautomator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.preference.PreferenceManager

class HotwordService : Service() {

    private var recognizer: SpeechRecognizer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground()
        startHotwordLoop()
    }

    private fun startForeground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val chanId = "automator_hotword"
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val chan = NotificationChannel(chanId, "Automator Hotword", NotificationManager.IMPORTANCE_MIN)
            nm.createNotificationChannel(chan)
            val n: Notification = NotificationCompat.Builder(this, chanId)
                .setContentTitle("Automator listening")
                .setContentText("Say your hotword to start a command")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build()
            startForeground(2, n)
        }
    }

    private fun startHotwordLoop() {
        stopRecognizer()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        val prefs = PreferenceManager.getDefaultSharedPreferences(this)
        val hotword = prefs.getString("hotword", "automator")?.lowercase() ?: "automator"

        val intent = RecognizerIntent().apply {
            action = RecognizerIntent.ACTION_RECOGNIZE_SPEECH
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        recognizer?.setRecognitionListener(SimpleRecognitionListener(
            onFinal = { text ->
                val heard = text.lowercase()
                if(heard.contains(hotword)){
                    startCommandCapture()
                }
                startHotwordLoop()
            },
            onErrorText = { _ ->
                startHotwordLoop()
            },
            onPartial = { _ -> }
        ))
        recognizer?.startListening(intent)
    }

    private fun startCommandCapture() {
        val i = Intent(this, VoiceCommandActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun stopRecognizer(){
        recognizer?.destroy()
        recognizer = null
    }

    override fun onDestroy() {
        stopRecognizer()
        super.onDestroy()
    }
}